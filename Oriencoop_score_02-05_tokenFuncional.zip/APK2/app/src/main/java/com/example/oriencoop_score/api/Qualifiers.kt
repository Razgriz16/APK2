package com.example.oriencoop_score.api
import javax.inject.Qualifier

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class MisProductosCredito

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class MisProductosAhorro

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class MisProductosLcc

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class MisMovimientosAhorro

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class MisMovimientosCredito