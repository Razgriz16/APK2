package com.example.oriencoop_score.model


data class Indicador(
    val Dolar: String,
    val Euro: String,
    val UF: String,
    val UTM: String,
)
