package com.example.oriencoop_score.api

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    object ApiConfig {
        const val BASE_URL = "http://192.168.120.8:8001/v1/"
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    @Named("api-cliente")
    fun provideRetrofitCliente(okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl("http://192.168.120.8:5001/v1/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    @Provides
    @Singleton
    fun provideRetrofit(okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(ApiConfig.BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }


    @Provides
    @Singleton
    @Named("mindicators")
    fun provideRetrofitMindicators(okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl("http://172.20.0.57:8080/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    /********************************* SERVICIOS RETROFIT *************************************/

    @Provides
    @Singleton
    fun mindicatorsService(@Named("mindicators") retrofit: Retrofit): MindicatorInterface {
        return retrofit.create(MindicatorInterface::class.java)
    }

    /****** SERVICIOS API-CLIENTE ******/
    @Provides
    @Singleton
    fun provideLoginService(@Named("api-cliente") retrofit: Retrofit): LoginService {
        return retrofit.create(LoginService::class.java)
    }

    @Provides
    @Singleton
    fun provideClienteInfoService(@Named("api-cliente") retrofit: Retrofit): ClienteService {
        return retrofit.create(ClienteService::class.java)
    }

    /****** SERVICIOS API-PARAMETRO ******/
    @Provides
    @Singleton
    fun provideFacturasService(retrofit: Retrofit): FacturasService {
        return retrofit.create(FacturasService::class.java)
    }

    @Provides
    @Singleton
    fun provideSucursalesService(retrofit: Retrofit): SucursalesService {
        return retrofit.create(SucursalesService::class.java)
    }

    /****** SERVICIOS API-CREDITO ******/
    @Provides
    @Singleton
    @MisProductosCredito
    fun provideMisProductosService(retrofit: Retrofit): MisProductosService {
        return retrofit.create(MisProductosService::class.java)
    }

    @Provides
    @Singleton
    fun provideMovimientosService(retrofit: Retrofit): MovimientosService {
        return retrofit.create(MovimientosService::class.java)
    }

    /****** SERVICIOS API-AHORRO ******/
    @Provides
    @Singleton
    @MisProductosAhorro
    fun provideMisProductosServiceAhorro(retrofit: Retrofit): MisProductosService {
        return retrofit.create(MisProductosService::class.java)
    }

    @Provides
    @Singleton
    @MisMovimientosAhorro
    fun provideMovimientosServiceAhorro(retrofit: Retrofit): MovimientosService {
        return retrofit.create(MovimientosService::class.java)
    }

    /****** SERVICIOS API-LCC ******/
    @Provides
    @Singleton
    @MisProductosLcc
    fun provideMisProductosServiceLcc(retrofit: Retrofit): MisProductosService {
        return retrofit.create(MisProductosService::class.java)
    }
}