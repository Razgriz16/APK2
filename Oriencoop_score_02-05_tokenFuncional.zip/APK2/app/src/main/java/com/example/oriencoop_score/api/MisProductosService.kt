package com.example.oriencoop_score.api

import com.example.oriencoop_score.model.CreditoCuotas
import com.example.oriencoop_score.model.CuentaAhorro
import com.example.oriencoop_score.model.CuentaCapResponse
import com.example.oriencoop_score.model.DapResponse
import com.example.oriencoop_score.model.Lcc
import com.example.oriencoop_score.model.LcrResponse
import com.example.oriencoop_score.utility.ApiResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Path
import retrofit2.http.Query

interface MisProductosService {

    /**
     * Estructura de los endpoints: http://ip:port/v1/{api a la que se quiere ir}/{ruta dentro de la api}
     * Ejemplo: http://192.168.120.8:8001/v1/parametro/comunas
     */
    @GET("creditos/creditos")
    suspend fun getCreditoCuotas(
        @Query("rut") rut: String,
        @Query("estado") estado: Int = 2,
        @Header("Authorization") token: String
    ): Response<ApiResponse<CreditoCuotas>>

    @GET("ahorro/cuenta-ahorro")
    suspend fun getAhorro(
        @Query("rut-titular") rut: String,
        @Header("Authorization") token: String
    ): Response<ApiResponse<CuentaAhorro>>

    @GET("cuenta_cap/{rut}")
    suspend fun getCuentaCap(
        @Header("Authorization") token: String,
        @Path("rut") rut: String
    ): Response<CuentaCapResponse>

    @GET("dap/{rut}")
    suspend fun getDap(
        @Header("Authorization") token: String,
        @Path("rut") rut: String
    ): Response<List<DapResponse>>

    @GET("lcc/lineacc")
    suspend fun getLcc(
        @Query("rut") rut: String,
        @Header("Authorization") token: String
    ): Response<ApiResponse<Lcc>>

    @GET("lcr/{rut}")
    suspend fun getLcr(
        @Header("Authorization") token: String,
        @Path("rut") rut: String
    ): Response<LcrResponse>
}

