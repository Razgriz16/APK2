import android.util.Log
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.LiveData
import com.example.oriencoop_score.MainDispatcherRule
import com.example.oriencoop_score.SessionManager
import com.example.oriencoop_score.SessionManager.token
import com.example.oriencoop_score.model.CuentaCapResponse
import com.example.oriencoop_score.repository.CuentaCapRepository
import com.example.oriencoop_score.view_model.CuentaCapViewModel
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.mockk
import io.mockk.MockKAnnotations
import io.mockk.every
import io.mockk.impl.annotations.RelaxedMockK
import io.mockk.mockkObject
import io.mockk.mockkStatic
import io.mockk.unmockkAll
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestCoroutineDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runBlockingTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import com.example.oriencoop_score.Result

@ExperimentalCoroutinesApi
class CuentaCapViewModelTest {

    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule() // Coroutine rule

    private lateinit var mockTokenFlow: MutableStateFlow<String>
    private lateinit var mockUsernameFlow: MutableStateFlow<String>

    @Before
    fun setup() {
        MockKAnnotations.init(this)
        mockkObject(SessionManager) // Mock SessionManager

        // Mock Logs
        mockkStatic(Log::class)
        every { Log.d(any(), any()) } returns 0
        every { Log.e(any(), any()) } returns 0

        // Initialize valid token/rut
        mockTokenFlow = MutableStateFlow("47942041-4801-42f9-b541-14c852fda5fc")
        mockUsernameFlow = MutableStateFlow("5980334")

        every { SessionManager.token } returns mockTokenFlow.asStateFlow()
        every { SessionManager.username } returns mockUsernameFlow.asStateFlow()
    }

    @After
    fun tearDown() {
        unmockkAll() // Clean up mocks after each test
    }

    @Test
    fun `when token or rut are blank, post error and skip repository call`() = runBlocking {
        // Given: Set empty values
        mockTokenFlow.value = ""
        mockUsernameFlow.value = ""

        // Create a fresh mock repository for isolation
        val freshRepo = mockk<CuentaCapRepository>(relaxed = true)

        // When: Initialize ViewModel (triggers init block)
        val viewModel = CuentaCapViewModel(freshRepo)

        // Then: Error message is posted
        assertEquals("Token o Rut no pueden estar vacíos", viewModel.error.value)

        // Verify repository was never called
        coVerify(exactly = 0) { freshRepo.getCuentaCap(any(), any()) }
    }

    @Test
    fun `when repository returns success, update cuentaCapData`() = runBlocking {
        // Arrange
        val mockData = CuentaCapResponse(
            FECHAAPERTURA = "2023-01-01",
            NROCUENTA = 123456789L,
            SALDOCONTABLE = "1000.00",
            TIPOCUENTA = "Ahorro"
        )
        val freshRepo = mockk<CuentaCapRepository>()

        // Stub repository to return mockData
        coEvery { freshRepo.getCuentaCap(any(), any()) } returns Result.Success(mockData)

        // Act: Initialize ViewModel (triggers init block)
        val viewModel = CuentaCapViewModel(freshRepo)

        // Assert: Verify data is posted and loading state updates
        assertEquals(mockData, viewModel.cuentaCapData.value)
        assertNull("Error should be null", viewModel.error.value)
        assertEquals("Loading should be false", false, viewModel.isLoading.value)

        // Verify repository was called with correct token/rut
        coVerify {
            freshRepo.getCuentaCap(mockTokenFlow.value, mockUsernameFlow.value)
        }
    }

    @Test
    fun `when repository returns error, post error message`() = runBlocking {
        // Arrange
        val errorMessage = "API Failure"
        val freshRepo = mockk<CuentaCapRepository>()

        // Stub repository to return error
        coEvery { freshRepo.getCuentaCap(any(), any()) } returns
                Result.Error(Exception(errorMessage))

        // Act: Initialize ViewModel
        val viewModel = CuentaCapViewModel(freshRepo)

        // Assert: Verify error message and loading state
        assertEquals(errorMessage, viewModel.error.value)
        assertNull("Data should be null", viewModel.cuentaCapData.value)
        assertEquals("Loading should be false", false, viewModel.isLoading.value)

        // Verify repository call
        coVerify {
            freshRepo.getCuentaCap(mockTokenFlow.value, mockUsernameFlow.value)
        }
    }
}