package com.example.oriencoop_score.repository


class LoginRepositoryTest