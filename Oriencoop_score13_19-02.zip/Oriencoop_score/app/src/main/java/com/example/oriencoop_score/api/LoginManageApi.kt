package com.example.oriencoop_score.api

import com.example.oriencoop_score.model.ClienteInfoResponse
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object LoginManageApi {

    // Configuración del OkHttpClient
    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    // Configuración de Retrofit
    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl("http://192.168.120.8:5000/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    // Servicios de Retrofit
    val loginService: LoginService by lazy {
        retrofit.create(LoginService::class.java)
    }

    val misProductosService: MisProductosService by lazy {
        retrofit.create(MisProductosService::class.java)
    }
    /*
    val cuentaCapService: CuentaCapService by lazy {
        retrofit.create(CuentaCapService::class.java)
    }*/

    val movimientosService: MovimientosService by lazy {
        retrofit.create(MovimientosService::class.java)
    }

    val cuentaAhorroService: CuentaAhorroService by lazy {
        retrofit.create(CuentaAhorroService::class.java)
    }

    val movimientosAhorroService: MovimientosAhorroService by lazy {
        retrofit.create(MovimientosAhorroService::class.java)
    }

    val creditoCuotasService: CreditoCuotasService by lazy {
        retrofit.create(CreditoCuotasService::class.java)
    }

    val movimientosCreditosService: MovimientosCreditos by lazy {
        retrofit.create(MovimientosCreditos::class.java)
    }

    val lccService: LccService by lazy {
        retrofit.create(LccService::class.java)
    }
    val movimientosLccService: MovimientosLccService by lazy {
        retrofit.create(MovimientosLccService::class.java)
    }
    /*
    val clienteInfoService: ClienteInfoService by lazy {
        retrofit.create(ClienteInfoService::class.java)
    }
    */
}
