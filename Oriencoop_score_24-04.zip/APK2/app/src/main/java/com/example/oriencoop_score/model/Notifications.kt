package com.example.oriencoop_score.model

data class Notifications(
    val TITULO: String,
    val DESCRIPCION: String,
    val DATE: String,
    val TIME: String
)