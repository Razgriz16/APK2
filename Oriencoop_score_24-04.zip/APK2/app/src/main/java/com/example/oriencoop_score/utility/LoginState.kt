package com.example.oriencoop_score.utility
/*
import com.example.oriencoop_score.model.UserLoginNewRes

// Sealed class to represent different states of the login process
sealed class LoginState {
    object Idle : LoginState()
    object Loading : LoginState()
    data class Success(val data: UserLoginNewRes) : LoginState()
    data class Error(val message: String?) : LoginState()
}
*/
