package com.example.oriencoop_score.api
import javax.inject.Qualifier

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class MisProductosCredito

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class MisProductosAhorro