package com.example.oriencoop_score.model

/*
data class IndicadoresEconomicos(
    val version: String,
    val autor: String,
    val fecha: String,
    val uf: Indicador,
    val ivp: Indicador,
    val dolar: Indicador,
    val dolar_intercambio: Indicador,
    val euro: Indicador,
    val ipc: Indicador,
    val utm: Indicador,
    val imacec: Indicador,
    val tpm: Indicador,
    val libra_cobre: Indicador,
    val tasa_desempleo: Indicador,
    val bitcoin: Indicador
)

data class Indicador(
    val codigo: String,
    val nombre: String,
    val unidad_medida: String,
    val fecha: String,
    val valor: String
)
 */
data class Indicador(
    val Dolar: String,
    val Euro: String,
    val UF: String,
    val UTM: String,
)
