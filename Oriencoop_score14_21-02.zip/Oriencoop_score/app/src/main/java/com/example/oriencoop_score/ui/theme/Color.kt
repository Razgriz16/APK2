package com.example.oriencoop_score.ui.theme

import androidx.compose.ui.graphics.Color

val azul = Color(0xFF006FB6)
val verde = Color(0xFF067211)
val verdeClaro= Color(0xFF60cc5a)

val rojo = Color(0xFFbd0000)
val gris = Color(0xFFcccccc)
val amarillo = Color(0xFFf49600)

val blanco = Color(0xFFFFFFFF)
val negro = Color(0xFF000000)

