package com.example.oriencoop_score.model

data class ClienteInfoResponse(
    val CALLENUMEROS: String,
    val EMAIL: String,
    val NOMBRE: String,
    val NUMERO: String,
    val RUTCOMPLETO: String
)
