package com.example.oriencoop_score.model

data class LcrResponse(
    val CUPOAUTORIZADO: String,
    val CUPODISPONIBLE: String,
    val CUPOUTILIZADO: String,
    val DESCRIPCIONPROD: String,
    val FECHAATIVACION: String,
    val NUMEROCUENTA: String,
    val SUCURSAL: String,
    val TIPO: String
)